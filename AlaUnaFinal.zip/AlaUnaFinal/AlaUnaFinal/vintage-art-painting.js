/*var seconds = 86400;
countDiv=document.getElementById('countdown1'),
secondPass,
countdown = setInterval(function(){
    "use strict";
    secondPass();

},1000);
function secondPass(){
    "use strict";
    var minutes = Math.floor((seconds/60)),
    remSeconds = seconds % 60;
    if(seconds<10){
        remSeconds="0"+remSeconds;
    }
countDiv.innerHTML = minutes+ ":" +remSeconds;
if(seconds > 0 ){
    seconds = seconds -1 ;
}
else{
    clearInterval(countdown);
    countDiv.innerHTML="DONE";
}
}*/
// Set the date we're counting down to
const c = [
new Date("Nov 20, 2021 01:30:40").getTime(),new Date("Nov 22, 2021 03:23:07").getTime(),
new Date("Nov 20, 2021 12:10:10").getTime(),new Date("Jan 23, 2022 00:00:00").getTime(),
new Date("Nov 20, 2021 05:50:55").getTime(),new Date("Dec 5, 2021 23:10:00").getTime(),
new Date("Nov 25, 2021 07:33:50").getTime(),new Date("Dec 5, 2021 00:00:00").getTime(),
new Date("Nov 28, 2021 15:17:19").getTime(),new Date("Jan 9, 2022 18:18:18").getTime(),
new Date("Dec 8, 2021 21:27:00").getTime(),new Date("Jan 2, 2022 00:00:00").getTime(),
new Date("Jul 7, 2022 07:07:07").getTime(),new Date("Apr 15, 2022 03:03:03").getTime(),
new Date("Aug 19, 2022 04:04:04").getTime(),new Date("Apr 27, 2022 19:19:19").getTime(),
new Date("Jan 20, 2022 22:22:22").getTime(),new Date("Dec 16, 2021 15:47:03").getTime(),
new Date("Feb 15, 2022 16:02:00").getTime(),new Date("Jan 24, 2022 18:30:54").getTime(),
new Date("Dec 12, 2021 21:12:12").getTime(),new Date("Dec 25, 2021 21:12:25").getTime(),
new Date("Feb 15, 2022 22:01:15").getTime(),new Date("Jan 9, 2022 22:01:09").getTime()
];                                                                  
const b = [
    "countdown1","countdown2",
    "countdown3","countdown4",
    "countdown5","countdown6",
    "countdown7","countdown8",
    "countdown9","countdown10",
    "countdown11","countdown12",
    "countdown13","countdown14",
    "countdown15","countdown16",
    "countdown17","countdown18",
    "countdown19","countdown20",
    "countdown21","countdown22",
    "countdown23","countdown24"
];
// Update the count down every 1 second
for(let i=0;i<c.length;i++){
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = c[i] - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in countdown elements
  document.getElementById(b[i]).innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write "Sold Out" 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById(b[i]).innerHTML = "SOLD OUT";
  }
}, 1000);
}